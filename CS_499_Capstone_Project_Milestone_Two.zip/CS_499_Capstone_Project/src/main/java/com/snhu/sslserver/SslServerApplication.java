package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * A Spring Boot application that provides a RESTful endpoint for generating
 * SHA-256 hashes of input strings. This example demonstrates basic secure
 * application design and is being enhanced as part of a software engineering capstone.
 */
@SpringBootApplication
@RestController
public class SslServerApplication {

    private static final Logger logger = LoggerFactory.getLogger(SslServerApplication.class);

    /**
     * Main method that launches the Spring Boot application.
     *
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        logger.info("Starting SSL Server Application...");
        SpringApplication.run(SslServerApplication.class, args);
    }

    /**
     * REST endpoint that returns a SHA-256 hash of a sample string.
     *
     * @return String containing the original data and its SHA-256 checksum
     */
    @GetMapping("/hash")
    public String getHash() {
        String data = "Hello World Check Sum!";
        logger.info("Received request at /hash endpoint with static data: {}", data);
        String checksum = HashUtil.calculateSHA256(data);
        logger.info("Checksum successfully calculated.");
        return "Developer: Darius Stewart \n Original String: " + data + "\n SHA-256 Checksum: " + checksum;
    }

    // Method removed; now using HashUtil for SHA-256 calculation
}
