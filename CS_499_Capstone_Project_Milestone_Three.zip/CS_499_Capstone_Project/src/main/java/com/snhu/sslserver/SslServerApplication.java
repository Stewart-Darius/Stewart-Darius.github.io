package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A Spring Boot application that provides a RESTful endpoint for generating
 * SHA-256 hashes of input strings. This example demonstrates basic secure
 * application design and is being enhanced as part of a software engineering capstone.
 */
@SpringBootApplication
@RestController
public class SslServerApplication {

    private static final Logger logger = LoggerFactory.getLogger(SslServerApplication.class);

    // Hash cache to store previously computed hashes
    private final Map<String, String> hashCache = new ConcurrentHashMap<>();

    /**
     * Main method that launches the Spring Boot application.
     *
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        logger.info("Starting SSL Server Application...");
        SpringApplication.run(SslServerApplication.class, args);
    }

    /**
     * REST endpoint that returns a SHA-256 hash of the given string.
     * If the string has been previously hashed, returns the cached value.
     *
     * @param data The input string
     * @return String containing the original data and its SHA-256 checksum
     */
    @GetMapping("/hash")
    public String getHash(@RequestParam String data) {
        logger.info("Received request to hash input: {}", data);
        String checksum = hashCache.computeIfAbsent(data, HashUtil::calculateSHA256);
        logger.info("Returning checksum (cached or newly computed).");
        return "Developer: Darius Stewart\nOriginal String: " + data + "\nSHA-256 Checksum: " + checksum;
    }
}
