package com.snhu.sslserver.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HashRecordDao {

    private static final Logger logger = LoggerFactory.getLogger(HashRecordDao.class);
    private static final String DB_URL = "jdbc:sqlite:hash_records.db";

    public HashRecordDao() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String sql = """
                CREATE TABLE IF NOT EXISTS hash_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    original_input TEXT NOT NULL,
                    hashed_output TEXT NOT NULL,
                    timestamp TEXT NOT NULL
                );
                """;
            stmt.execute(sql);
            logger.info("Database initialized successfully.");
        } catch (SQLException e) {
            logger.error("Database initialization error", e);
        }
    }

    public void insertRecord(String original, String hash, LocalDateTime timestamp) {
        String sql = "INSERT INTO hash_records (original_input, hashed_output, timestamp) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, original);
            pstmt.setString(2, hash);
            pstmt.setString(3, timestamp.toString());
            pstmt.executeUpdate();
            logger.info("Record inserted into database successfully.");
        } catch (SQLException e) {
            logger.error("Database insertion error", e);
        }
    }

    public List<String> getAllRecords() {
        List<String> results = new ArrayList<>();
        String sql = "SELECT * FROM hash_records";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String record = "ID: " + rs.getInt("id")
                        + ", Input: " + rs.getString("original_input")
                        + ", Hash: " + rs.getString("hashed_output")
                        + ", Timestamp: " + rs.getString("timestamp");
                results.add(record);
            }
            logger.info("Records retrieved successfully.");

        } catch (SQLException e) {
            logger.error("Database retrieval error", e);
        }
        return results;
    }
}
