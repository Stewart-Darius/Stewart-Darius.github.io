package com.snhu.sslserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Utility class for hashing functions.
 */
public class HashUtil {

    private static final Logger logger = LoggerFactory.getLogger(HashUtil.class);

    /**
     * Calculates the SHA-256 hash of a given string.
     *
     * @param data The input string to hash
     * @return The SHA-256 hash as a hexadecimal string
     */
    public static String calculateSHA256(String data) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            logger.error("SHA-256 algorithm not found.", e);
            throw new RuntimeException("SHA-256 algorithm not found.", e);
        }
    }
}
