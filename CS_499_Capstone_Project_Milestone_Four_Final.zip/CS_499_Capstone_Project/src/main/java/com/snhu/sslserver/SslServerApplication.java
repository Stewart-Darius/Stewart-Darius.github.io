package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.snhu.sslserver.dao.HashRecordDao;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

/**
 * A Spring Boot application that provides a RESTful endpoint for generating
 * SHA-256 hashes of input strings. This example demonstrates secure
 * application design, algorithms, and now database integration.
 */
@SpringBootApplication
@RestController
public class SslServerApplication {

    private static final Logger logger = LoggerFactory.getLogger(SslServerApplication.class);

    private static final HashRecordDao hashDao = new HashRecordDao();

    public static void main(String[] args) {
        logger.info("Starting SSL Server Application...");
        SpringApplication.run(SslServerApplication.class, args);
    }

    /**
     * REST endpoint that returns a SHA-256 hash of a sample string.
     * Also stores the hash in the SQLite database.
     *
     * @return String containing the original data and its SHA-256 checksum
     */
    @GetMapping("/hash")
    public String getHash() {
        String data = "Hello World Check Sum!";
        logger.info("Received request at /hash endpoint with static data: {}", data);

        String checksum = HashUtil.calculateSHA256(data);
        logger.info("Checksum successfully calculated: {}", checksum);

        LocalDateTime now = LocalDateTime.now();
        hashDao.insertRecord(data, checksum, now);
        logger.info("Hash record inserted into database.");

        return "Developer: Darius Stewart \nOriginal String: " + data + "\nSHA-256 Checksum: " + checksum;
    }
}
